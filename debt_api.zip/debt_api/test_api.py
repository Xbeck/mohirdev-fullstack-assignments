import os
os.environ['DATABASE_URL']='sqlite:///:memory:'
import unittest
from fastapi.testclient import TestClient
from app import app,Base,engine

class APITests(unittest.TestCase):
    def setUp(self):
        Base.metadata.drop_all(engine)
        Base.metadata.create_all(engine)
        self.client=TestClient(app)
        self.creds={'username':'testuser','password':'Long-test-password-123'}
        self.assertEqual(self.client.post('/api/register/',json=self.creds).status_code,201)
        self.token=self.client.post('/api/login/',json=self.creds).json()['access_token']
        self.headers={'Authorization':'Bearer '+self.token}
        self.data={'debt_type':'owed_to','person_name':'Demo Person','amount':'12.50','currency':'USD',
                   'borrowed_at':'2026-01-01T10:00:00+00:00','due_at':'2026-02-01T10:00:00+00:00',
                   'reminder_at':'2026-01-31T10:00:00+00:00'}
    def test_auth_and_settings(self):
        self.assertEqual(self.client.post('/api/register/',json=self.creds).status_code,409)
        self.assertEqual(self.client.post('/api/login/',json={**self.creds,'password':'wrong-password'}).status_code,401)
        self.assertIn(self.client.get('/api/settings/').status_code,[401,403])
        self.assertEqual(self.client.get('/api/settings/',headers=self.headers).json()['currency'],'UZS')
        r=self.client.put('/api/settings/',json={'currency':'USD','reminder_minutes':60},headers=self.headers)
        self.assertEqual(r.json()['reminder_minutes'],60)
    def test_crud_filter_monitoring(self):
        r=self.client.post('/api/debts/',json=self.data,headers=self.headers)
        self.assertEqual(r.status_code,201)
        debt_id=r.json()['id']
        self.client.post('/api/debts/',json={**self.data,'debt_type':'owed_by','amount':'2.50'},headers=self.headers)
        self.client.post('/api/debts/',json={**self.data,'currency':'UZS','amount':'10000'},headers=self.headers)
        self.assertEqual(len(self.client.get('/api/debts/?debt_type=owed_by',headers=self.headers).json()),1)
        individual=self.client.get('/api/debts/?debt_type=individual',headers=self.headers).json()
        self.assertEqual(len(individual[0]['debts']),3)
        totals=self.client.get('/api/monitoring/',headers=self.headers).json()['currencies']
        self.assertEqual(float(totals[0]['balance']),10)
        r=self.client.put(f'/api/debts/{debt_id}/',json={**self.data,'amount':'20.00'},headers=self.headers)
        self.assertEqual(r.status_code,200)
        self.assertEqual(self.client.delete(f'/api/debts/{debt_id}/',headers=self.headers).status_code,204)
        self.assertEqual(self.client.delete(f'/api/debts/{debt_id}/',headers=self.headers).status_code,404)
    def test_isolation_validation(self):
        debt_id=self.client.post('/api/debts/',json=self.data,headers=self.headers).json()['id']
        other={'username':'otheruser','password':'Another-password-123'}
        self.client.post('/api/register/',json=other)
        h={'Authorization':'Bearer '+self.client.post('/api/login/',json=other).json()['access_token']}
        self.assertEqual(self.client.get('/api/debts/',headers=h).json(),[])
        self.assertEqual(self.client.put(f'/api/debts/{debt_id}/',json=self.data,headers=h).status_code,404)
        self.assertEqual(self.client.delete(f'/api/debts/{debt_id}/',headers=h).status_code,404)
        for changes in [{'amount':'-1'},{'due_at':'2025-01-01T00:00:00Z'},{'debt_type':'individual'},{'currency':'XXX'},{'person_name':'  '}]:
            self.assertEqual(self.client.post('/api/debts/',json={**self.data,**changes},headers=self.headers).status_code,422)

if __name__=='__main__':
    unittest.main()
