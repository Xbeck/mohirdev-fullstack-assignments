# Qarzlarni hisoblash

Bu loyiha olingan va berilgan qarzlarni saqlaydi. Har bir odam va valyuta bo‘yicha jami summani ko‘rsatadi. FastAPI, SQLAlchemy va PostgreSQL ishlatilgan.

## Ishga tushirish

Python va Docker o‘rnatilgan bo‘lishi kerak. Docker dasturini oching, keyin loyiha papkasida quyidagi buyruqlarni bajaring:

```sh
python -m pip install -r requirements.txt
docker compose up -d
uvicorn app:app --reload
```

Brauzerda `http://127.0.0.1:8000/docs` manzilini oching. Shu sahifada barcha so‘rovlarni sinash mumkin.

1. `/api/register/` orqali hisob yarating.
2. `/api/login/` orqali kiring.
3. Qaytgan tokenni `Authorize` oynasiga kiriting. Token 24 soat amal qiladi.

## Asosiy manzillar

| Manzil | Nima qiladi |
|---|---|
| GET /api/settings/ | Sozlamalarni ko‘rsatadi |
| PUT /api/settings/ | Valyuta va eslatma sozlamalarini o‘zgartiradi |
| GET /api/monitoring/ | Olingan, berilgan qarzlar va ularning farqini ko‘rsatadi |
| GET /api/debts/ | Qarzlar ro‘yxatini beradi |
| POST /api/debts/ | Yangi qarz qo‘shadi |
| PUT /api/debts/{id}/ | Tanlangan qarzni o‘zgartiradi |
| DELETE /api/debts/{id}/ | Tanlangan qarzni o‘chiradi |

`{id}` o‘rniga qarz raqamini yozing. Har bir foydalanuvchi faqat o‘z qarzlarini ko‘radi.

Ro‘yxatni `debt_type=owed_to` (berilgan), `debt_type=owed_by` (olingan) yoki `debt_type=individual` (odamlar bo‘yicha) bilan saralash mumkin. `person_name` orqali ism bo‘yicha qidiriladi.

Turli valyutalar bir-biriga qo‘shilmaydi. Eslatma vaqti saqlanadi, lekin bildirishnoma yuborish xizmati yo‘q.

## Tekshirish

```sh
python -m unittest -v
```

Testlar vaqtinchalik SQLite bazasida ishlaydi. Oddiy ishga tushirishda PostgreSQL ishlatiladi. PostgreSQL bilan alohida tekshiruv bajarilmagan.

`compose.yaml` ichidagi `local-demo` paroli mahalliy namuna uchun. Baza ulanishini `DATABASE_URL` orqali o‘zgartirish mumkin.
