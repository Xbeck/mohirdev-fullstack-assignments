# Qarz monitoringi — FastAPI / SQLAlchemy / PostgreSQL

Python 3.12+. `local-demo` faqat lokal namuna paroli.

```sh
pip install -r requirements.txt
docker compose up -d
uvicorn app:app --reload
```

`http://127.0.0.1:8000/docs` — Swagger. `/api/register/` orqali ro‘yxatdan o‘ting,
`/api/login/` tokenini Authorize oynasiga kiriting. Token 24 soat amal qiladi.
Sozlamalar GET/PUT `/api/settings/`, statistika GET `/api/monitoring/`.
Qarzlar GET/POST `/api/debts/`, PUT/DELETE `/api/debts/{id}/`.
`debt_type=owed_to`, `owed_by`, `individual` va `person_name` filtrlari bor.
Individual natija har bir odam bo‘yicha guruhlanadi.
Valyutalar alohida hisoblanadi; kurs berilmagani sabab avtomatik konvertatsiya yo‘q.
`reminder_at` har bir qarzda, umumiy `reminder_minutes` sozlamalarda saqlanadi.
Bildirishnoma jo‘natish servisi topshiriqda talab qilinmagan, bu API eslatma vaqtini saqlaydi.

```sh
python -m unittest -v
```
Unit testlar alohida in-memory SQLite bazada ishlaydi. Oddiy ishga tushirish PostgreSQL’dan foydalanadi.
`DATABASE_URL` muhit o‘zgaruvchisi ulanishni almashtiradi. Parollar PBKDF2-SHA256 va tasodifiy salt bilan,
tokenlar esa SHA256 xeshi bilan saqlanadi. Har bir foydalanuvchi faqat o‘z qarzlarini ko‘radi.
