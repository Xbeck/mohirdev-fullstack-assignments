"""Debt tracking API. Monetary totals are grouped by currency, never mixed."""
import hashlib
import hmac
import os
import secrets
import time
from contextlib import asynccontextmanager
from datetime import datetime
from decimal import Decimal
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, AwareDatetime, model_validator
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Numeric, DateTime, Text, select, CheckConstraint
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import StaticPool

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql+psycopg://debt:local-demo@localhost:5432/debts')
options = {'connect_args':{'check_same_thread':False}} if DATABASE_URL.startswith('sqlite') else {}
if DATABASE_URL.endswith(':memory:'):
    options['poolclass'] = StaticPool
engine = create_engine(DATABASE_URL, **options)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

class User(Base):
    __tablename__='users'
    id=Column(Integer,primary_key=True)
    username=Column(String(80),unique=True,nullable=False)
    password_hash=Column(String(256),nullable=False)
    currency=Column(String(3),nullable=False,default='UZS')
    reminder_minutes=Column(Integer,nullable=False,default=1440)

class Token(Base):
    __tablename__='tokens'
    digest=Column(String(64),primary_key=True)
    user_id=Column(Integer,ForeignKey('users.id'),nullable=False)
    expires=Column(Integer,nullable=False)

class Debt(Base):
    __tablename__='debts'
    id=Column(Integer,primary_key=True)
    user_id=Column(Integer,ForeignKey('users.id'),index=True,nullable=False)
    debt_type=Column(String(10),nullable=False)
    person_name=Column(String(150),index=True,nullable=False)
    amount=Column(Numeric(18,2),nullable=False)
    currency=Column(String(3),nullable=False)
    description=Column(Text,nullable=False,default='')
    borrowed_at=Column(DateTime(timezone=True),nullable=False)
    due_at=Column(DateTime(timezone=True),nullable=False)
    reminder_at=Column(DateTime(timezone=True),nullable=True)
    __table_args__=(CheckConstraint('amount > 0'),CheckConstraint("debt_type IN ('owed_to','owed_by')"))

def db():
    with SessionLocal() as session:
        yield session

def password_hash(password, salt=None):
    salt=salt or secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex()
    return salt+':'+digest

security=HTTPBearer()
def current_user(credentials:HTTPAuthorizationCredentials=Depends(security), session:Session=Depends(db)):
    digest=hashlib.sha256(credentials.credentials.encode()).hexdigest()
    token=session.get(Token,digest)
    if not token or token.expires<=int(time.time()):
        raise HTTPException(401,'Invalid or expired token')
    user=session.get(User,token.user_id)
    if not user:
        raise HTTPException(401,'User not found')
    return user

class Credentials(BaseModel):
    username:str=Field(min_length=3,max_length=80,pattern=r'^[A-Za-z0-9_.-]+$')
    password:str=Field(min_length=10,max_length=128)

Currency=Literal['UZS','USD','EUR','GBP','RUB']
class SettingsIn(BaseModel):
    currency:Currency='UZS'
    reminder_minutes:int=Field(default=1440,ge=0,le=525600)

class DebtIn(BaseModel):
    model_config=ConfigDict(str_strip_whitespace=True)
    debt_type:Literal['owed_to','owed_by']
    person_name:str=Field(min_length=1,max_length=150)
    amount:Decimal=Field(gt=0,max_digits=18,decimal_places=2)
    currency:Currency
    description:str=Field(default='',max_length=5000)
    borrowed_at:AwareDatetime
    due_at:AwareDatetime
    reminder_at:AwareDatetime|None=None
    @model_validator(mode='after')
    def dates(self):
        if self.due_at<self.borrowed_at:
            raise ValueError('due_at must be after borrowed_at')
        if self.reminder_at and not self.borrowed_at<=self.reminder_at<=self.due_at:
            raise ValueError('reminder_at must be between borrowed_at and due_at')
        return self

def debt_dict(debt):
    return {name:getattr(debt,name) for name in ['id','debt_type','person_name','amount','currency','description','borrowed_at','due_at','reminder_at']}

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    yield

app=FastAPI(title='Qarz monitoringi',version='1.0.0',lifespan=lifespan,
    description='Opaque bearer tokens expire after 24 hours. UPDATE uses HTTP PUT. Amounts are grouped by currency.')

@app.post('/api/register/',status_code=201)
def register(data:Credentials,session:Session=Depends(db)):
    user=User(username=data.username.lower(),password_hash=password_hash(data.password))
    session.add(user)
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raise HTTPException(409,'Username already exists')
    return {'id':user.id,'username':user.username}

@app.post('/api/login/')
def login(data:Credentials,session:Session=Depends(db)):
    user=session.scalar(select(User).where(User.username==data.username.lower()))
    if not user or not hmac.compare_digest(password_hash(data.password,user.password_hash.split(':')[0]),user.password_hash):
        raise HTTPException(401,'Invalid credentials')
    token=secrets.token_urlsafe(32)
    session.add(Token(digest=hashlib.sha256(token.encode()).hexdigest(),user_id=user.id,expires=int(time.time())+86400))
    session.commit()
    return {'access_token':token,'token_type':'bearer','expires_in':86400}

@app.get('/api/settings/')
def get_settings(user:User=Depends(current_user)):
    return {'currency':user.currency,'reminder_minutes':user.reminder_minutes}

@app.put('/api/settings/')
def update_settings(data:SettingsIn,user:User=Depends(current_user),session:Session=Depends(db)):
    user.currency=data.currency
    user.reminder_minutes=data.reminder_minutes
    session.commit()
    return get_settings(user)

@app.post('/api/debts/',status_code=201)
def create_debt(data:DebtIn,user:User=Depends(current_user),session:Session=Depends(db)):
    debt=Debt(user_id=user.id,**data.model_dump())
    session.add(debt)
    session.commit()
    return debt_dict(debt)

def owned_debt(debt_id,user,session):
    debt=session.scalar(select(Debt).where(Debt.id==debt_id,Debt.user_id==user.id))
    if not debt:
        raise HTTPException(404,'Debt not found')
    return debt

@app.put('/api/debts/{debt_id}/')
def update_debt(debt_id:int,data:DebtIn,user:User=Depends(current_user),session:Session=Depends(db)):
    debt=owned_debt(debt_id,user,session)
    for key,value in data.model_dump().items():
        setattr(debt,key,value)
    session.commit()
    return debt_dict(debt)

@app.delete('/api/debts/{debt_id}/',status_code=204)
def delete_debt(debt_id:int,user:User=Depends(current_user),session:Session=Depends(db)):
    session.delete(owned_debt(debt_id,user,session))
    session.commit()
    return Response(status_code=204)

@app.get('/api/debts/')
def debts(debt_type:Literal['owed_to','owed_by','individual']|None=None,person_name:str|None=None,
          user:User=Depends(current_user),session:Session=Depends(db)):
    query=select(Debt).where(Debt.user_id==user.id).order_by(Debt.id)
    if debt_type in ('owed_to','owed_by'):
        query=query.where(Debt.debt_type==debt_type)
    if person_name:
        query=query.where(Debt.person_name==person_name.strip())
    records=list(session.scalars(query))
    if debt_type=='individual':
        grouped={}
        for debt in records:
            grouped.setdefault(debt.person_name,[]).append(debt_dict(debt))
        return [{'person_name':name,'debts':rows} for name,rows in grouped.items()]
    return [debt_dict(debt) for debt in records]

@app.get('/api/monitoring/')
def monitoring(user:User=Depends(current_user),session:Session=Depends(db)):
    grouped={}
    for debt in session.scalars(select(Debt).where(Debt.user_id==user.id)):
        totals=grouped.setdefault(debt.currency,{'owed_to':Decimal(0),'owed_by':Decimal(0)})
        totals[debt.debt_type]+=debt.amount
    return {'preferred_currency':user.currency,'currencies':[
        {'currency':currency,**totals,'balance':totals['owed_to']-totals['owed_by']}
        for currency,totals in sorted(grouped.items())]}
