# Bootstrap sahifalari

Bu loyihada uchta sahifa bor:

- `basic.html` — tugmalar, ogohlantirishlar va boshqa oddiy elementlar.
- `forms.html` — ma’lumot kiritish formasi.
- `tables.html` — jadvallar.

## Ochish

Arxivni oching va `basic.html` faylini brauzerda ishga tushiring. Boshqa sahifalarga menyu orqali o‘tasiz.

Bootstrap internet orqali yuklanadi, shuning uchun internet kerak. Sahifa bezaklari `style.css` faylida. Ko‘rinish telefon ekraniga ham moslashadi.

Forma faqat namuna: kiritilgan ma’lumotlar hech qayerga yuborilmaydi. Jadvaldagi ismlar ham namuna uchun yozilgan.
