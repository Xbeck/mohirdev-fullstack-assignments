# Bootstrap practice

Open basic.html, forms.html or tables.html. Three responsive pages with separate style.css. Bootstrap 5.3.3 is loaded from jsDelivr (internet required). The form validates in the browser and sends no data. All table entries are fictional.

Dashboard Kit inspired educational implementation: sidebar, top bar, cards, Basic components, Form elements and Bootstrap tables.
