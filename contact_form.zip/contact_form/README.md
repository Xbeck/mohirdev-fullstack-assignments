# Contact Form — Django
Python 3.12+.
```sh
pip install -r requirements.txt
python manage.py migrate
python manage.py test
python manage.py runserver
```
`/` — forma, POST bilan saqlash va `/xabarlar` ga redirect. Xatoli ma’lumot qayta ko‘rsatiladi.
CSRF himoyasi va template escaping yoqilgan. Jadval mobil qurilmada gorizontal aylanadi.
Topshiriq talabiga ko‘ra xabarlar jadvali ochiq: bu lokal o‘quv demo, real shaxsiy xabarlar kiritmang.
