# Xabar yuborish formasi

Bu Django loyihasi foydalanuvchi yuborgan xabarni bazaga saqlaydi va xabarlar jadvalini ko‘rsatadi.

## Ishga tushirish

Python o‘rnatilgan bo‘lishi kerak. Loyiha papkasida terminal ochib, quyidagi buyruqlarni bajaring:

```sh
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Brauzerda `http://127.0.0.1:8000/` manzilini oching. Ism, familiya, telefon, email va xabarni kiriting. Yuborgandan keyin `/xabarlar` sahifasi ochiladi.

Xato kiritilgan ma’lumot forma ichida ko‘rsatiladi. Bu o‘quv loyihasida xabarlar jadvali hammaga ochiq.

## Tekshirish

```sh
python manage.py test
```

Testlar xabar saqlanishi, kerakli sahifaga o‘tish, xato ma’lumot va forma himoyasini tekshiradi.
