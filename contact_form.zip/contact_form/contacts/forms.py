from django import forms
from .models import Message
class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['first_name','last_name','phone','email','message']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs['class'] = 'form-control'
