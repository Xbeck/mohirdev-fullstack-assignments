from django.db import models
from django.core.validators import RegexValidator
class Message(models.Model):
    first_name = models.CharField('Ism', max_length=80)
    last_name = models.CharField('Familiya', max_length=80)
    phone = models.CharField('Telefon raqam', max_length=20, validators=[RegexValidator(r'^\+?[0-9\s()-]{7,20}$', 'Telefon raqam noto‘g‘ri')])
    email = models.EmailField('Email')
    message = models.TextField('Yuborilgan xabar', max_length=5000)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ['-created_at', '-id']
