from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods
from .forms import MessageForm
from .models import Message
@require_http_methods(['GET', 'POST'])
def contact(request):
    form = MessageForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('messages')
    return render(request, 'contact.html', {'form':form})
def messages(request):
    return render(request, 'messages.html', {'messages':Message.objects.all()})
