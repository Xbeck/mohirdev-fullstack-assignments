from django.test import TestCase, Client
from .models import Message
class ContactTests(TestCase):
    def test_save_redirect_and_escape(self):
        payload = dict(first_name='Test',last_name='User',phone='+998901234567',email='test@example.com',message='<script>alert(1)</script>')
        self.assertEqual(self.client.get('/').status_code,200)
        response = self.client.post('/',payload)
        self.assertRedirects(response,'/xabarlar')
        self.assertEqual(Message.objects.count(),1)
        self.assertContains(self.client.get('/xabarlar'),'&lt;script&gt;')
    def test_invalid_and_csrf(self):
        self.client.post('/',{'email':'bad'})
        self.assertEqual(Message.objects.count(),0)
        self.assertEqual(Client(enforce_csrf_checks=True).post('/',{}).status_code,403)
