from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth
from django.urls import path
from posts import views
urlpatterns = [path('admin/',admin.site.urls),path('',views.home,name='home'),
  path('register/',views.register,name='register'),
  path('login/',auth.LoginView.as_view(template_name='form.html'),name='login'),
  path('logout/',auth.LogoutView.as_view(),name='logout'),
  path('posts/new/',views.create,name='create'),path('posts/<int:pk>/',views.detail,name='detail')]
if settings.DEBUG: urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
