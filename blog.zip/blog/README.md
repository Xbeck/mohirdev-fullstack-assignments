# Django blog
O‘quv loyihasi. Ro‘yxatdan o‘tish, kirish/POST chiqish, rasm/kategoriya/teg bilan maqola, izohlar va administrator moderatsiyasi.
## Ishga tushirish
```sh
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py test
python manage.py runserver
```
/admin/ orqali avval Category va Tag yarating. Foydalanuvchi /posts/new/ da maqola yuboradi.
Administrator Post.approved ni yoqmaguncha maqola ochiq sahifalarda ko‘rinmaydi.
`recommended` belgisini administrator belgilaydi. Haftalik/oylik ommaboplik oxirgi 7/30 kun ichidagi sahifa tashriflaridan hisoblanadi, jami ko‘rishlar alohida saqlanadi.
Rasm formasi Pillow bilan tekshiriladi, 5 MB gacha. Testlar moderatsiya, yashirin maqolaga 404, HTML escape, izohlar, auth va barcha saralashlarni tekshiradi.
SQLite bazasi migrate bilan yaratiladi. Haqiqiy foydalanuvchi ma’lumotlari repositoryga kiritilmagan.
Lokal demo: internetga joylashdan oldin DJANGO_DEBUG=0, alohida DJANGO_SECRET_KEY, ALLOWED_HOSTS, HTTPS va media server sozlang; ommaviy sayt uchun tashriflar/izohlarni rate-limit qiling.
