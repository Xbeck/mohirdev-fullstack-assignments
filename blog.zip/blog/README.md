# Django blog

Bu saytda foydalanuvchi ro‘yxatdan o‘tib, maqola yozishi va izoh qoldirishi mumkin. Yangi maqola administrator tasdiqlagandan keyin saytda ko‘rinadi.

## Ishga tushirish

Loyiha papkasida terminal oching:

```sh
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

`createsuperuser` buyrug‘i administrator hisobini yaratadi. Ism va parolni o‘zingiz kiriting.

Brauzerda `http://127.0.0.1:8000/` manzilini oching.

## Foydalanish

1. `/admin/` sahifasiga kirib, bo‘limlar (`Category`) va teglar (`Tag`) qo‘shing.
2. Oddiy foydalanuvchi hisobida “Maqola yozish” tugmasini bosing.
3. Sarlavha, matn, bo‘lim, teg va rasmni kiriting. Rasm 5 MB dan oshmasin.
4. Administrator maqolaning `approved` belgisini yoqsa, maqola hammaga ko‘rinadi.
5. `recommended` belgisi yoqilgan maqola tavsiya qilinganlar orasida chiqadi.

Bosh sahifada yangi, eng ko‘p ko‘rilgan, haftalik, oylik va tavsiya qilingan maqolalarni tanlash mumkin. Haftalik va oylik ro‘yxat oxirgi 7 va 30 kundagi ko‘rishlar asosida tuziladi.

## Tekshirish

```sh
python manage.py test
```

Testlar kirish, ro‘yxatdan o‘tish, maqolani tasdiqlash va izohlarni tekshiradi.

Loyiha kompyuterda ishlatish uchun sozlangan. Internetga joylashda maxfiy kalit, ruxsat berilgan sayt manzillari va HTTPS sozlanishi, `DJANGO_DEBUG=0` qilinishi kerak.
