from django.contrib import admin
from .models import Post, Category, Tag, Comment
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['title','author','approved','recommended','views']
    list_filter = ['approved','recommended','category']
    search_fields = ['title','content']
    list_editable = ['approved','recommended']
    readonly_fields = ['views','created_at']
admin.site.register([Category,Tag,Comment])
