from datetime import timedelta
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.db.models import Count, Q, F
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Post, Visit
from .forms import PostForm, CommentForm
def home(request):
    posts = Post.objects.filter(approved=True).select_related('author','category').prefetch_related('tags')
    mode = request.GET.get('sort','new')
    if mode == 'popular': posts = posts.order_by('-views','-created_at')
    elif mode in ('week','month'):
        since = timezone.now()-timedelta(days=7 if mode == 'week' else 30)
        posts = posts.annotate(period_views=Count('visits',filter=Q(visits__created_at__gte=since))).order_by('-period_views','-created_at')
    elif mode == 'recommended': posts = posts.filter(recommended=True)
    from django.core.paginator import Paginator
    return render(request,'home.html',{'page':Paginator(posts,12).get_page(request.GET.get('page')),'mode':mode})
def register(request):
    form = UserCreationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        login(request,form.save())
        return redirect('home')
    return render(request,'form.html',{'form':form,'title':'Ro‘yxatdan o‘tish'})
@login_required
def create(request):
    form = PostForm(request.POST or None,request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        post = form.save(commit=False)
        post.author = request.user
        post.save()
        form.save_m2m()
        messages.success(request,'Maqola saqlandi. Administrator tasdiqlagach chop etiladi.')
        return redirect('home')
    return render(request,'form.html',{'form':form,'title':'Yangi maqola'})
def detail(request,pk):
    post = get_object_or_404(Post.objects.select_related('author','category').prefetch_related('tags'),pk=pk,approved=True)
    form = CommentForm(request.POST or None)
    if request.method == 'POST':
        if not request.user.is_authenticated: return redirect('login')
        if form.is_valid():
            comment = form.save(commit=False)
            comment.author, comment.post = request.user,post
            comment.save()
            return redirect('detail',pk=post.pk)
    else:
        Post.objects.filter(pk=pk).update(views=F('views')+1)
        Visit.objects.create(post=post)
    return render(request,'detail.html',{'post':post,'form':form,'comments':post.comments.select_related('author')})
