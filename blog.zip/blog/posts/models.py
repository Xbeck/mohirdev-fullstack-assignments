from django.conf import settings
from django.db import models
class Category(models.Model):
    name = models.CharField(max_length=80, unique=True)
    def __str__(self): return self.name
class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    def __str__(self): return self.name
class Post(models.Model):
    author = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    content = models.TextField(max_length=50000)
    image = models.ImageField(upload_to='posts/%Y/%m/',blank=True)
    category = models.ForeignKey(Category,on_delete=models.PROTECT)
    tags = models.ManyToManyField(Tag,blank=True)
    approved = models.BooleanField(default=False)
    recommended = models.BooleanField(default=False)
    views = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ['-created_at','-id']
    def __str__(self): return self.title
class Comment(models.Model):
    post = models.ForeignKey(Post,on_delete=models.CASCADE,related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    text = models.TextField(max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: ordering = ['created_at']
class Visit(models.Model):
    post = models.ForeignKey(Post,on_delete=models.CASCADE,related_name='visits')
    created_at = models.DateTimeField(auto_now_add=True,db_index=True)
