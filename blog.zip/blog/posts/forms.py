from django import forms
from .models import Post, Comment
class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title','content','image','category','tags']
    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image and image.size > 5*1024*1024:
            raise forms.ValidationError('Rasm 5 MB dan kichik bo‘lsin.')
        return image
class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['text']
