from django.test import TestCase
from django.contrib.auth.models import User
from .models import Post,Category,Comment
class BlogTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('demo',password='example-pass-123')
        self.category = Category.objects.create(name='Python')
    def test_moderation_and_comments(self):
        self.client.force_login(self.user)
        response = self.client.post('/posts/new/',{'title':'Pending title','content':'<script>bad</script>','category':self.category.pk})
        self.assertEqual(response.status_code,302)
        post = Post.objects.get()
        self.assertFalse(post.approved)
        self.assertNotContains(self.client.get('/'),'Pending title')
        self.assertEqual(self.client.get(f'/posts/{post.pk}/').status_code,404)
        post.approved=True; post.save()
        self.assertContains(self.client.get(f'/posts/{post.pk}/'),'&lt;script&gt;')
        self.client.post(f'/posts/{post.pk}/',{'text':'Useful'})
        self.assertEqual(Comment.objects.get().author,self.user)
        post.refresh_from_db(); self.assertEqual(post.views,1)
    def test_auth_and_filters(self):
        self.assertEqual(self.client.get('/posts/new/').status_code,302)
        self.assertEqual(self.client.post('/register/',{'username':'reader','password1':'Example-safe-234','password2':'Example-safe-234'}).status_code,302)
        self.assertEqual(self.client.post('/logout/').status_code,302)
        self.assertEqual(self.client.post('/login/',{'username':'reader','password':'Example-safe-234'}).status_code,302)
        for mode in ['new','popular','week','month','recommended']:
            self.assertEqual(self.client.get('/?sort='+mode).status_code,200)
