# Omborxona hisobi

Bu loyiha mahsulot tayyorlash uchun ombordan qancha xomashyo kerakligini hisoblaydi. Django va Django REST Framework ishlatilgan.

## Ishga tushirish

Loyiha papkasida quyidagi buyruqlarni bajaring:

```sh
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed
python manage.py runserver
```

Arxiv ichida namuna ma’lumotlar yozilgan SQLite bazasi bor. `seed` buyrug‘i mavjud ma’lumotlarni o‘zgartirmaydi.

## Foydalanish

`http://127.0.0.1:8000/api/calculate/` manziliga POST so‘rov yuboring. Bitta mahsulot yoki mahsulotlar ro‘yxatini berish mumkin:

```json
[{"product_code":238923,"quantity":30},{"product_code":498723,"quantity":20}]
```

Avval kichik ID raqamli partiyadan olinadi. Bir mahsulotga ajratilgan xomashyo keyingi mahsulotga qayta ajratilmaydi. Xomashyo yetmasa, yetishmagan qismi `warehouse_id: null` va `price: null` bilan qaytadi.

Hisoblash bazadagi haqiqiy qoldiqni kamaytirmaydi.

Topshiriqda shim uchun ip miqdori ikki xil ko‘rsatilgan. Namuna javobga mos bo‘lishi uchun bazada har bir shimga 15 metr ip belgilangan.

## Tekshirish

```sh
python manage.py test
```
