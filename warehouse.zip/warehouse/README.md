# Omborxona — DRF API
```sh
pip install -r requirements.txt
python manage.py migrate
python manage.py seed
python manage.py test
python manage.py runserver
```
POST `/api/calculate/`: bitta obyekt yoki massiv qabul qiladi.
```json
[{"product_code":238923,"quantity":30},{"product_code":498723,"quantity":20}]
```
DRF browsable API hujjatlari: brauzerda `/api/calculate/` ni oching.
Ombor qoldig‘i bazada o‘zgarmaydi; bitta so‘rov ichida partiyalar takror sarflanmaydi.
FIFO tartibi: ID. Pul va miqdor hisoblari Decimal bilan bajariladi.
Shartdagi misolda shim ipi uchun ziddiyat bor (10 m va 300/20=15 m).
Seed kutilgan JSON natijasiga mos 15 m ishlatadi; retsept bazadan olinadi, kodga qotirilmagan.
Sample SQLite bazasi qo‘shilgan; `seed` mavjud ma’lumotni o‘zgartirmaydi.
