from django.urls import path
from django.contrib import admin
from inventory.views import CalculateView
urlpatterns = [path('api/calculate/',CalculateView.as_view()),path('admin/',admin.site.urls)]
