from decimal import Decimal
from .models import Warehouse
def calculate(items):
    # Local reservations: never save() or update() database stock.
    batches = list(Warehouse.objects.select_related('material').order_by('id'))
    remaining = {batch.id:batch.remainder for batch in batches}
    result = []
    for item in items:
        product, quantity = item['product'], item['quantity']
        materials = []
        for component in product.recipe.select_related('material').order_by('id'):
            needed = component.quantity * quantity
            for batch in batches:
                if batch.material_id != component.material_id or remaining[batch.id] <= 0:
                    continue
                used = min(needed, remaining[batch.id])
                if used <= 0:
                    break
                materials.append(dict(warehouse_id=batch.id,material_name=component.material.material_name,qty=used,price=batch.price))
                remaining[batch.id] -= used
                needed -= used
            if needed > 0:
                materials.append(dict(warehouse_id=None,material_name=component.material.material_name,qty=needed,price=None))
        result.append(dict(product_name=product.product_name,product_qty=quantity,product_materials=materials))
    return {'result':result}
