from django.core.management.base import BaseCommand
from django.db import transaction
from inventory.models import Product,Material,ProductMaterial,Warehouse
class Command(BaseCommand):
    help = 'Create sample data once; preserves existing stock.'
    @transaction.atomic
    def handle(self,*args,**options):
        if Product.objects.exists() or Warehouse.objects.exists():
            self.stdout.write('Data exists; nothing changed.')
            return
        mats = [Material.objects.create(material_name=n) for n in ['Mato','Ip','Tugma','Zamok']]
        shirt = Product.objects.create(product_name='Koylak',product_code='238923')
        pants = Product.objects.create(product_name='Shim',product_code='498723')
        for product, recipe in [(shirt,[(0,'0.8'),(2,'5'),(1,'10')]),(pants,[(0,'1.4'),(1,'15'),(3,'1')])]:
            for index,qty in recipe:
                ProductMaterial.objects.create(product=product,material=mats[index],quantity=qty)
        for index,qty,price in [(0,12,1500),(0,40,1600),(1,40,500),(1,300,550),(2,150,300),(3,20,2000)]:
            Warehouse.objects.create(material=mats[index],remainder=qty,price=price)
        self.stdout.write('Sample data created.')
