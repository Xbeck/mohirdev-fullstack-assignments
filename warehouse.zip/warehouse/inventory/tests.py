from django.test import TestCase
from django.core.management import call_command
from rest_framework.test import APIClient
from .models import Warehouse
class CalculationTests(TestCase):
    def setUp(self):
        call_command('seed',verbosity=0)
        self.client=APIClient()
    def test_shared_stock_shortage_and_no_mutation(self):
        before=list(Warehouse.objects.values_list('remainder',flat=True))
        data=[{'product_code':238923,'quantity':30},{'product_code':498723,'quantity':20}]
        r=self.client.post('/api/calculate/',data,format='json')
        self.assertEqual(r.status_code,200)
        mats=r.data['result'][1]['product_materials']
        self.assertEqual(mats[0]['warehouse_id'],2)
        self.assertEqual(mats[0]['qty'],28)
        self.assertEqual(mats[2]['warehouse_id'],None)
        self.assertEqual(mats[2]['qty'],260)
        self.assertEqual(before,list(Warehouse.objects.values_list('remainder',flat=True)))
        self.assertEqual(r.data,self.client.post('/api/calculate/',data,format='json').data)
    def test_validation(self):
        for data in [[],{'product_code':'missing','quantity':1},{'product_code':238923,'quantity':0},{'product_code':238923,'quantity':'x'}]:
            self.assertEqual(self.client.post('/api/calculate/',data,format='json').status_code,400)
