from django.contrib import admin
from .models import Product, Material, ProductMaterial, Warehouse
admin.site.register([Product,Material,ProductMaterial,Warehouse])
