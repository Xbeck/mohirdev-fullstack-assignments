from django.db import models
from django.core.validators import MinValueValidator
from decimal import Decimal
class Product(models.Model):
    product_name = models.CharField(max_length=150)
    product_code = models.CharField(max_length=40, unique=True)
class Material(models.Model):
    material_name = models.CharField(max_length=150, unique=True)
class ProductMaterial(models.Model):
    product = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='recipe')
    material = models.ForeignKey(Material,on_delete=models.PROTECT)
    quantity = models.DecimalField(max_digits=18,decimal_places=4,validators=[MinValueValidator(Decimal('0.0001'))])
    class Meta:
        constraints = [models.UniqueConstraint(fields=['product','material'],name='unique_recipe'), models.CheckConstraint(condition=models.Q(quantity__gt=0),name='positive_recipe')]
class Warehouse(models.Model):
    material = models.ForeignKey(Material,on_delete=models.PROTECT)
    remainder = models.DecimalField(max_digits=18,decimal_places=4,validators=[MinValueValidator(0)])
    price = models.DecimalField(max_digits=18,decimal_places=2,validators=[MinValueValidator(0)])
    class Meta:
        constraints = [models.CheckConstraint(condition=models.Q(remainder__gte=0),name='nonnegative_stock'),models.CheckConstraint(condition=models.Q(price__gte=0),name='nonnegative_price')]
