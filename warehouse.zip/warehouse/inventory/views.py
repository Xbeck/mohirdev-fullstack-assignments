from rest_framework import serializers
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Product
from .services import calculate
class OrderSerializer(serializers.Serializer):
    product_code = serializers.CharField(max_length=40)
    quantity = serializers.IntegerField(min_value=1,max_value=1000000)
    def validate(self, attrs):
        try:
            attrs['product'] = Product.objects.get(product_code=attrs['product_code'])
        except Product.DoesNotExist:
            raise serializers.ValidationError({'product_code':'Mahsulot topilmadi.'})
        if not attrs['product'].recipe.exists():
            raise serializers.ValidationError('Mahsulot retsepti kiritilmagan.')
        return attrs
class CalculateView(APIView):
    """POST one order or a list: [{"product_code":"238923","quantity":30}].

    FIFO by batch ID. Shortages have warehouse_id=null, price=null.
    Stock remains unchanged, including repeated requests.
    """
    def post(self, request):
        data = request.data if isinstance(request.data,list) else [request.data]
        if not data or len(data)>100:
            raise serializers.ValidationError('1–100 ta mahsulot yuboring.')
        serializer = OrderSerializer(data=data,many=True)
        serializer.is_valid(raise_exception=True)
        return Response(calculate(serializer.validated_data))
